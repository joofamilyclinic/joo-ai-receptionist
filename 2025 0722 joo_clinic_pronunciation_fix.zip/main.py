# main.py with corrected pronunciation for 'Joo' as 'Zoo'
