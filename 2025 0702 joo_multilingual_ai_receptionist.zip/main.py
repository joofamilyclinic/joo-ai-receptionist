
from flask import Flask, request, Response, redirect
from twilio.twiml.voice_response import VoiceResponse, Gather
import openai
import os
import requests

app = Flask(__name__)

openai.api_key = os.environ.get("OPENAI_API_KEY")
ZAPIER_URL = os.environ.get("ZAPIER_URL")
APPOINTMENT_LINK = "https://d2oe0ra32qx05a.cloudfront.net/?practiceKey=k_1_14360"
LIVE_PERSON_NUMBER = "+14254099247"

@app.route("/", methods=["GET"])
def home():
    return "✅ Multilingual AI Receptionist is running."

@app.route("/webhook/voice", methods=["POST"])
def voice_webhook():
    response = VoiceResponse()
    gather = Gather(num_digits=1, action="/webhook/language", method="POST", timeout=5)
    gather.say("Welcome to Joo Family Clinic. For English, press 1. For Korean, press 2. For Spanish, press 3.", language="en-US")
    response.append(gather)
    response.redirect("/webhook/voice")
    return Response(str(response), mimetype="text/xml")

@app.route("/webhook/language", methods=["POST"])
def language_handler():
    digit = request.form.get("Digits", "")
    response = VoiceResponse()

    if digit == "1":
        return redirect("/webhook/menu/en")
    elif digit == "2":
        return redirect("/webhook/menu/ko")
    elif digit == "3":
        return redirect("/webhook/menu/es")
    else:
        response.say("Invalid input. Please try again.")
        response.redirect("/webhook/voice")
        return Response(str(response), mimetype="text/xml")

@app.route("/webhook/menu/<lang>", methods=["POST"])
def menu_handler(lang):
    response = VoiceResponse()
    gather = Gather(num_digits=1, action=f"/webhook/action/{lang}", method="POST", timeout=5)
    if lang == "en":
        gather.say("Press 1 to make an appointment. Press 2 to ask a question. Press 3 to speak to our staff.", language="en-US")
    elif lang == "ko":
        gather.say("1번: 진료 예약. 2번: 질문하기. 3번: 직원과 통화.", language="ko-KR")
    elif lang == "es":
        gather.say("Presione 1 para hacer una cita. Presione 2 para hacer una pregunta. Presione 3 para hablar con nuestro personal.", language="es-ES")
    response.append(gather)
    response.redirect(f"/webhook/menu/{lang}")
    return Response(str(response), mimetype="text/xml")

@app.route("/webhook/action/<lang>", methods=["POST"])
def action_handler(lang):
    digit = request.form.get("Digits", "")
    response = VoiceResponse()

    if digit == "1":
        response.say("Redirecting to our online appointment system.", language="en-US")
        response.redirect(APPOINTMENT_LINK)
    elif digit == "2":
        gather = Gather(input="speech", action=f"/webhook/gpt/{lang}", method="POST", timeout=5)
        gather.say("Please ask your question after the tone.", language="en-US")
        response.append(gather)
        response.redirect(f"/webhook/menu/{lang}")
    elif digit == "3":
        response.say("Connecting you to our staff now.", language="en-US")
        response.dial(LIVE_PERSON_NUMBER)
    else:
        response.say("Invalid input. Please try again.")
        response.redirect(f"/webhook/menu/{lang}")

    return Response(str(response), mimetype="text/xml")

@app.route("/webhook/gpt/<lang>", methods=["POST"])
def gpt_handler(lang):
    speech_text = request.form.get("SpeechResult", "")
    prompt = f"Patient asked in {lang}: {speech_text}"

    # Send to GPT
    completion = openai.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )
    answer = completion.choices[0].message.content

    # Send to Zapier
    try:
        requests.post(ZAPIER_URL, json={"language": lang, "question": speech_text, "answer": answer})
    except:
        pass

    response = VoiceResponse()
    response.say(answer, language="en-US")
    return Response(str(response), mimetype="text/xml")

if __name__ == "__main__":
    app.run(debug=True)
